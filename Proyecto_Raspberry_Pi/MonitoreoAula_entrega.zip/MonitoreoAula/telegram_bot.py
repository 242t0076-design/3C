"""Bot de Telegram para consultar el monitoreo del aula."""
import hmac
import os
import time

import requests
from dotenv import load_dotenv

from conexion import obtener_conexion

load_dotenv()

TOKEN = os.getenv("TELEGRAM_TOKEN", "")
# IDs de chat autorizados, separados por comas (ver .env)
PERMITIDOS = {i.strip() for i in os.getenv("TELEGRAM_CHAT_IDS", "").split(",") if i.strip()}
API = f"https://api.telegram.org/bot{TOKEN}"
CODIGO = os.getenv("BOT_CODIGO", "")
ARCHIVO_IDS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chats_autorizados.txt")
MINUTOS_SIN_DATOS = 5  # avisa si la ESP32 lleva mas tiempo sin mandar datos

AYUDA = (
    "Comandos disponibles:\n"
    "/actual - ultima medicion\n"
    "/promedio - resumen de las ultimas 24 horas\n"
    "/alertas - comparar la ultima medicion con los umbrales\n"
    "/estado - ver si la ESP32 sigue enviando datos\n"
    "/id - ver tu ID de chat"
)


def consultar(sql, params=()):
    """Ejecuta un SELECT y devuelve una lista de diccionarios."""
    conexion = obtener_conexion()
    try:
        cursor = conexion.cursor(dictionary=True)
        cursor.execute(sql, params)
        filas = cursor.fetchall()
        cursor.close()
        return filas
    finally:
        conexion.close()


def cmd_actual():
    filas = consultar("""
        SELECT a.nombre, a.ubicacion, m.fecha_hora,
               m.temperatura, m.humedad, m.presion, m.iluminacion
        FROM mediciones AS m
        INNER JOIN aulas AS a ON a.id_aula = m.id_aula
        ORDER BY m.fecha_hora DESC, m.id_medicion DESC
        LIMIT 1
    """)
    if not filas:
        return "Todavia no hay mediciones."
    f = filas[0]
    return (
        f"{f['nombre']} ({f['ubicacion']})\n"
        f"Hora: {f['fecha_hora']:%Y-%m-%d %H:%M:%S}\n"
        f"Temperatura: {f['temperatura']:.1f} C\n"
        f"Humedad: {f['humedad']:.1f} %\n"
        f"Presion: {f['presion']:.1f} hPa\n"
        f"Luz: {f['iluminacion']:.1f} lx"
    )


def cmd_promedio():
    filas = consultar("""
        SELECT a.nombre, COUNT(*) AS lecturas,
               AVG(m.temperatura) AS t_prom, MIN(m.temperatura) AS t_min,
               MAX(m.temperatura) AS t_max, AVG(m.humedad) AS h_prom,
               AVG(m.presion) AS p_prom, AVG(m.iluminacion) AS lux_prom
        FROM mediciones AS m
        INNER JOIN aulas AS a ON a.id_aula = m.id_aula
        WHERE m.fecha_hora >= NOW() - INTERVAL 24 HOUR
        GROUP BY a.id_aula, a.nombre
    """)
    if not filas:
        return "No hay mediciones en las ultimas 24 horas."
    f = filas[0]
    return (
        f"{f['nombre']} - ultimas 24 horas ({f['lecturas']} lecturas)\n"
        f"Temperatura: promedio {f['t_prom']:.1f} C "
        f"(min {f['t_min']:.1f}, max {f['t_max']:.1f})\n"
        f"Humedad promedio: {f['h_prom']:.1f} %\n"
        f"Presion promedio: {f['p_prom']:.1f} hPa\n"
        f"Luz promedio: {f['lux_prom']:.1f} lx"
    )


def cmd_alertas():
    filas = consultar("""
        SELECT u.variable, u.minimo, u.maximo,
               CASE u.variable
                   WHEN 'temperatura' THEN m.temperatura
                   WHEN 'humedad'     THEN m.humedad
                   WHEN 'presion'     THEN m.presion
                   ELSE m.iluminacion
               END AS valor
        FROM umbrales AS u
        INNER JOIN (
            SELECT * FROM mediciones
            ORDER BY fecha_hora DESC, id_medicion DESC
            LIMIT 1
        ) AS m ON m.id_aula = u.id_aula
        ORDER BY u.variable
    """)
    if not filas:
        return "No hay umbrales o mediciones para comparar."
    lineas = []
    for f in filas:
        fuera = f["valor"] < f["minimo"] or f["valor"] > f["maximo"]
        estado = "FUERA DE RANGO" if fuera else "OK"
        lineas.append(
            f"{f['variable']}: {f['valor']:.1f} "
            f"(rango {f['minimo']:.0f} a {f['maximo']:.0f}) -> {estado}"
        )
    return "Ultima medicion contra umbrales:\n" + "\n".join(lineas)


def cmd_estado():
    filas = consultar(
        "SELECT TIMESTAMPDIFF(MINUTE, MAX(fecha_hora), NOW()) AS minutos FROM mediciones"
    )
    minutos = filas[0]["minutos"]
    if minutos is None:
        return "Todavia no hay mediciones."
    if minutos > MINUTOS_SIN_DATOS:
        return f"Atencion: la ultima medicion fue hace {minutos} minutos. Revisa la ESP32."
    return f"Todo bien: la ultima medicion fue hace {minutos} minuto(s)."


COMANDOS = {
    "/start": lambda: AYUDA,
    "/ayuda": lambda: AYUDA,
    "/actual": cmd_actual,
    "/promedio": cmd_promedio,
    "/alertas": cmd_alertas,
    "/estado": cmd_estado,
}


def responder(comando):
    funcion = COMANDOS.get(comando)
    if funcion is None:
        return "No entendi ese comando.\n\n" + AYUDA
    try:
        return funcion()
    except Exception as error:  # base de datos caida, etc.
        print("Error al consultar:", error)
        return "No pude consultar la base de datos."


def enviar(chat_id, texto):
    requests.post(API + "/sendMessage", json={"chat_id": chat_id, "text": texto}, timeout=15)


def cargar_ids():
    ids = set(PERMITIDOS)
    if os.path.exists(ARCHIVO_IDS):
        with open(ARCHIVO_IDS, encoding="utf8") as f:
            ids |= {linea.strip() for linea in f if linea.strip()}
    return ids


def guardar_id(chat_id):
    with open(ARCHIVO_IDS, "a", encoding="utf8") as f:
        f.write(chat_id + "\n")


def main():
    if not TOKEN:
        raise SystemExit("Falta TELEGRAM_TOKEN en el archivo .env")
    print("Bot iniciado. Codigo de acceso activo:", bool(CODIGO))
    offset = None
    while True:
        try:
            r = requests.get(
                API + "/getUpdates",
                params={"timeout": 30, "offset": offset},
                timeout=40,
            )
            datos = r.json()
            if not datos.get("ok"):
                print("Telegram respondio con error:", datos)
                time.sleep(10)
                continue
            for u in datos["result"]:
                offset = u["update_id"] + 1
                msg = u.get("message")
                if not msg or "text" not in msg:
                    continue
                chat_id = str(msg["chat"]["id"])
                partes = msg["text"].strip().split()
                if not partes:
                    continue
                comando = partes[0].split("@")[0].lower()
                if comando == "/id":
                    enviar(chat_id, f"Tu ID de chat es {chat_id}.")
                    continue
                autorizados = cargar_ids()
                if comando in ("/acceso", "/start") and len(partes) > 1:
                    if CODIGO and hmac.compare_digest(partes[1].encode(), CODIGO.encode()):
                        if chat_id not in autorizados:
                            guardar_id(chat_id)
                        enviar(chat_id, "Acceso concedido.\n\n" + AYUDA)
                    else:
                        enviar(chat_id, "Codigo incorrecto.")
                    continue
                if chat_id not in autorizados:
                    enviar(chat_id, "Para usar este bot escribe /acceso seguido del codigo.")
                    continue
                enviar(chat_id, responder(comando))
        except Exception as error:
            print("Error:", error)
            time.sleep(5)


if __name__ == "__main__":
    main()
