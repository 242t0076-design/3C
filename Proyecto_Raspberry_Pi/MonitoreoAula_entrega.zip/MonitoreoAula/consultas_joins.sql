-- =====================================================================
-- CONSULTAS Y JOINs - Monitoreo inteligente del aula
-- =====================================================================
USE `monitoreo_aula`;

-- 1) INNER JOIN: ultimas 10 mediciones con el nombre del aula
SELECT m.id_medicion, a.nombre AS aula, m.fecha_hora,
       m.temperatura, m.humedad, m.presion, m.iluminacion
FROM mediciones AS m
INNER JOIN aulas AS a ON a.id_aula = m.id_aula
ORDER BY m.fecha_hora DESC
LIMIT 10;

-- 2) LEFT JOIN + COUNT: cuantos sensores y mediciones tiene cada aula
--    (LEFT JOIN muestra tambien las aulas que aun no tienen datos)
SELECT a.nombre AS aula,
       COUNT(DISTINCT s.id_sensor)   AS sensores,
       COUNT(DISTINCT m.id_medicion) AS mediciones
FROM aulas AS a
LEFT JOIN sensores   AS s ON s.id_aula = a.id_aula
LEFT JOIN mediciones AS m ON m.id_aula = a.id_aula
GROUP BY a.id_aula, a.nombre;

-- 3) JOIN + agregados: temperatura promedio, minima y maxima por aula y dia
SELECT a.nombre AS aula, DATE(m.fecha_hora) AS dia,
       ROUND(AVG(m.temperatura), 2) AS temp_promedio,
       MIN(m.temperatura)           AS temp_minima,
       MAX(m.temperatura)           AS temp_maxima,
       COUNT(*)                     AS lecturas
FROM mediciones AS m
INNER JOIN aulas AS a ON a.id_aula = m.id_aula
GROUP BY a.nombre, DATE(m.fecha_hora)
ORDER BY dia DESC;

-- 4) JOIN con umbrales: mediciones con iluminacion por debajo del minimo permitido
SELECT a.nombre AS aula, m.fecha_hora, m.iluminacion,
       u.minimo AS luz_minima,
       ROUND(u.minimo - m.iluminacion, 2) AS faltante
FROM mediciones AS m
INNER JOIN aulas    AS a ON a.id_aula = m.id_aula
INNER JOIN umbrales AS u ON u.id_aula = m.id_aula AND u.variable = 'iluminacion'
WHERE m.iluminacion < u.minimo
ORDER BY m.fecha_hora DESC
LIMIT 10;

-- 5) Subconsulta: la medicion mas reciente de cada aula
SELECT a.nombre AS aula, m.fecha_hora, m.temperatura, m.humedad, m.presion, m.iluminacion
FROM mediciones AS m
INNER JOIN aulas AS a ON a.id_aula = m.id_aula
WHERE m.fecha_hora = (SELECT MAX(m2.fecha_hora)
                      FROM mediciones AS m2
                      WHERE m2.id_aula = m.id_aula);

-- 6) JOIN + GROUP_CONCAT: sensores de cada aula en una sola linea
SELECT a.nombre AS aula, a.ubicacion,
       GROUP_CONCAT(CONCAT(s.modelo, ' (', s.magnitud, ' en ', s.unidad, ')')
                    ORDER BY s.modelo, s.magnitud SEPARATOR ', ') AS sensores
FROM aulas AS a
INNER JOIN sensores AS s ON s.id_aula = a.id_aula
GROUP BY a.id_aula, a.nombre, a.ubicacion;

-- 7) Subconsulta con HAVING: aulas cuyo promedio de iluminacion es menor al minimo permitido
SELECT a.nombre AS aula, ROUND(AVG(m.iluminacion), 2) AS luz_promedio, u.minimo AS luz_minima_permitida
FROM mediciones AS m
INNER JOIN aulas    AS a ON a.id_aula = m.id_aula
INNER JOIN umbrales AS u ON u.id_aula = m.id_aula AND u.variable = 'iluminacion'
GROUP BY a.id_aula, a.nombre, u.minimo
HAVING AVG(m.iluminacion) < u.minimo;
