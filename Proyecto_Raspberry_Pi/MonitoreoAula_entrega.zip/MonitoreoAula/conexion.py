import os

import mysql.connector.pooling
from dotenv import load_dotenv

load_dotenv()

_pool = None


def obtener_conexion():
    """Devuelve una conexión del pool (se crea la primera vez que se pide).

    Al llamar a conexion.close() la conexión NO se cierra: regresa al pool
    para reutilizarse, así no se abre una conexión nueva en cada consulta.
    """
    global _pool
    if _pool is None:
        _pool = mysql.connector.pooling.MySQLConnectionPool(
            pool_name="monitoreo_aula",
            pool_size=5,
            host=os.getenv("DB_HOST"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD"),
            database=os.getenv("DB_NAME"),
        )
    return _pool.get_connection()
