import os

from conexion import obtener_conexion


def _id_aula():
    """Aula a la que pertenecen las mediciones de este servidor (ID_AULA en .env)."""
    return int(os.getenv("ID_AULA", "1"))


def guardar_medicion_bd(medicion):
    conexion = obtener_conexion()
    cursor = conexion.cursor()

    try:
        sql = """
            INSERT INTO mediciones (
                id_aula,
                fecha_hora,
                temperatura,
                humedad,
                presion,
                iluminacion,
                es_simulada
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """

        valores = (
            _id_aula(),
            medicion["fecha"],
            medicion["temperatura"],
            medicion["humedad"],
            medicion["presion"],
            medicion["iluminacion"],
            medicion["simulado"],
        )

        cursor.execute(sql, valores)
        conexion.commit()

    except Exception:
        # Si algo falla, se deshace la operación y se avisa a quien llamó.
        conexion.rollback()
        raise

    finally:
        cursor.close()
        conexion.close()


def obtener_mediciones_bd(limite=100):
    conexion = obtener_conexion()
    cursor = conexion.cursor(dictionary=True)

    try:
        cursor.execute(
            """
            SELECT
                m.id_medicion,
                a.nombre AS aula,
                m.fecha_hora AS fecha,
                m.temperatura,
                m.humedad,
                m.presion,
                m.iluminacion,
                m.es_simulada AS simulado
            FROM mediciones AS m
            INNER JOIN aulas AS a ON a.id_aula = m.id_aula
            WHERE m.id_aula = %s
            ORDER BY m.fecha_hora DESC, m.id_medicion DESC
            LIMIT %s
            """,
            (_id_aula(), limite),
        )

        filas = cursor.fetchall()
        for fila in filas:
            fila["fecha"] = fila["fecha"].strftime("%Y-%m-%d %H:%M:%S")
        return filas

    finally:
        cursor.close()
        conexion.close()


def obtener_usuario_activo(nombre_usuario):
    """Busca un usuario activo por nombre. Devuelve dict o None."""
    conexion = obtener_conexion()
    cursor = conexion.cursor(dictionary=True)

    try:
        cursor.execute(
            """
            SELECT id_usuario, nombre_usuario, password_hash, rol
            FROM usuarios
            WHERE nombre_usuario = %s AND activo = 1
            LIMIT 1
            """,
            (nombre_usuario,),
        )
        return cursor.fetchone()

    finally:
        cursor.close()
        conexion.close()
