"""Crea un usuario para entrar al panel. Uso:  python crear_usuario.py"""
import getpass
import sys

from werkzeug.security import generate_password_hash

from conexion import obtener_conexion


def main():
    nombre = input("Nombre de usuario: ").strip()
    if not nombre:
        sys.exit("El nombre no puede estar vacío.")

    contrasena = getpass.getpass("Contraseña (mínimo 8 caracteres): ")
    if len(contrasena) < 8:
        sys.exit("La contraseña es muy corta.")
    if contrasena != getpass.getpass("Repite la contraseña: "):
        sys.exit("Las contraseñas no coinciden.")

    rol = input("Rol [admin/usuario] (Enter = usuario): ").strip() or "usuario"
    if rol not in ("admin", "usuario"):
        sys.exit("Rol no válido.")

    conexion = obtener_conexion()
    cursor = conexion.cursor()
    try:
        cursor.execute(
            "INSERT INTO usuarios (nombre_usuario, password_hash, rol) "
            "VALUES (%s, %s, %s)",
            (nombre, generate_password_hash(contrasena), rol),
        )
        conexion.commit()
        print(f"Usuario '{nombre}' creado.")
    except Exception as error:
        conexion.rollback()
        sys.exit(f"No se pudo crear el usuario: {error}")
    finally:
        cursor.close()
        conexion.close()


if __name__ == "__main__":
    main()
