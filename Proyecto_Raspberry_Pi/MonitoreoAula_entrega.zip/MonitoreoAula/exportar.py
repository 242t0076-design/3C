"""Arma el Excel y el PDF de las ultimas mediciones."""
import io
from datetime import datetime
from xml.sax.saxutils import escape

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

ENCABEZADOS = [
    "Fecha y hora",
    "Temperatura (\u00b0C)",
    "Humedad (%)",
    "Presi\u00f3n (hPa)",
    "Luz (lux)",
    "Origen",
]


def _filas(mediciones):
    filas = []
    for m in mediciones:
        filas.append([
            m["fecha"],
            float(m["temperatura"]),
            float(m["humedad"]),
            float(m["presion"]),
            float(m["iluminacion"]),
            "Simulada" if m["simulado"] else "Sensor real",
        ])
    return filas


def generar_excel(mediciones, aula):
    libro = Workbook()
    hoja = libro.active
    hoja.title = "Ultimas 30 mediciones"

    hoja["A1"] = "Aula: " + aula
    hoja["A1"].font = Font(bold=True, size=13)
    hoja["A2"] = "Generado: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    for col, texto in enumerate(ENCABEZADOS, start=1):
        celda = hoja.cell(row=4, column=col, value=texto)
        celda.font = Font(bold=True, color="FFFFFF")
        celda.fill = PatternFill("solid", fgColor="12305A")
        celda.alignment = Alignment(horizontal="center")

    for numero, fila in enumerate(_filas(mediciones), start=5):
        for col, valor in enumerate(fila, start=1):
            hoja.cell(row=numero, column=col, value=valor)

    for letra, ancho in zip("ABCDEF", (22, 18, 14, 16, 12, 14)):
        hoja.column_dimensions[letra].width = ancho
    hoja.freeze_panes = "A5"

    salida = io.BytesIO()
    libro.save(salida)
    salida.seek(0)
    return salida


def generar_pdf(mediciones, aula):
    salida = io.BytesIO()
    documento = SimpleDocTemplate(
        salida, pagesize=A4, leftMargin=36, rightMargin=36,
        topMargin=36, bottomMargin=36, title="Ultimas mediciones",
    )
    estilos = getSampleStyleSheet()
    elementos = [
        Paragraph("Monitoreo inteligente del aula", estilos["Title"]),
        Paragraph("Aula: " + escape(aula) + " - ultimas "
                  + str(len(mediciones)) + " mediciones", estilos["Normal"]),
        Paragraph("Generado: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                  estilos["Normal"]),
        Spacer(1, 14),
    ]

    datos = [ENCABEZADOS]
    for f in _filas(mediciones):
        datos.append([f[0], f"{f[1]:.1f}", f"{f[2]:.1f}", f"{f[3]:.1f}", f"{f[4]:.1f}", f[5]])

    tabla = Table(datos, repeatRows=1, colWidths=[110, 85, 70, 80, 65, 75])
    tabla.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#12305A")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#BCCCDC")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1),
         [colors.white, colors.HexColor("#F0F4F8")]),
    ]))
    elementos.append(tabla)

    documento.build(elementos)
    salida.seek(0)
    return salida
