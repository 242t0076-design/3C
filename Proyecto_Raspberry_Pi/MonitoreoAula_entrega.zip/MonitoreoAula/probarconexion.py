
from conexion import obtener_conexion

conexion = None

try:
    conexion = obtener_conexion()

    if conexion.is_connected():
        print("¡Conexión con MySQL exitosa!")

except Exception as error:
    print("Error al conectar con MySQL:", error)

finally:
    if conexion and conexion.is_connected():
        conexion.close()
