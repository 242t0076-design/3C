-- =====================================================================
-- MODELO RELACIONAL - Monitoreo inteligente del aula
-- Ejecutar DESPUES de base_datos.sql (y del respaldo, si lo importas):
--     sudo mariadb < relacional.sql
-- Es seguro ejecutarlo mas de una vez.
-- =====================================================================
USE `monitoreo_aula`;

-- ------------------------------ DDL: tablas nuevas -------------------
-- Aula donde estan instalados los sensores (1 aula : N sensores / mediciones / umbrales)
CREATE TABLE IF NOT EXISTS aulas (
    id_aula     INT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(50)  NOT NULL UNIQUE,
    ubicacion   VARCHAR(100) NOT NULL,
    fecha_alta  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Sensores fisicos instalados en cada aula
CREATE TABLE IF NOT EXISTS sensores (
    id_sensor  INT AUTO_INCREMENT PRIMARY KEY,
    id_aula    INT          NOT NULL,
    modelo     VARCHAR(30)  NOT NULL,
    magnitud   VARCHAR(30)  NOT NULL,
    unidad     VARCHAR(10)  NOT NULL,
    interfaz   ENUM('I2C','analogica','digital') NOT NULL,
    CONSTRAINT fk_sensores_aula FOREIGN KEY (id_aula)
        REFERENCES aulas (id_aula) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT uq_sensor UNIQUE (id_aula, modelo, magnitud)
) ENGINE=InnoDB;

-- Rangos permitidos por aula y variable (para detectar mediciones fuera de limite)
CREATE TABLE IF NOT EXISTS umbrales (
    id_umbral  INT AUTO_INCREMENT PRIMARY KEY,
    id_aula    INT NOT NULL,
    variable   ENUM('temperatura','humedad','presion','iluminacion') NOT NULL,
    minimo     DECIMAL(9,2) NOT NULL,
    maximo     DECIMAL(9,2) NOT NULL,
    CONSTRAINT fk_umbrales_aula FOREIGN KEY (id_aula)
        REFERENCES aulas (id_aula) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT uq_umbral UNIQUE (id_aula, variable),
    CONSTRAINT ck_umbral_rango CHECK (minimo < maximo)
) ENGINE=InnoDB;

-- ------------------------------ DML: datos iniciales ------------------
-- >>> CAMBIA el nombre y la ubicacion por los de tu aula real <<<
INSERT INTO aulas (nombre, ubicacion)
SELECT 'Aula de Computo', 'Edificio principal'
WHERE NOT EXISTS (SELECT 1 FROM aulas);

INSERT IGNORE INTO sensores (id_aula, modelo, magnitud, unidad, interfaz)
SELECT a.id_aula, v.modelo, v.magnitud, v.unidad, v.interfaz
FROM (SELECT id_aula FROM aulas ORDER BY id_aula LIMIT 1) AS a
CROSS JOIN (
    SELECT 'BME280' AS modelo, 'temperatura' AS magnitud, 'C'   AS unidad, 'I2C' AS interfaz UNION ALL
    SELECT 'BME280', 'humedad',      '%',   'I2C' UNION ALL
    SELECT 'BME280', 'presion',      'hPa', 'I2C' UNION ALL
    SELECT 'BH1750', 'iluminacion',  'lx',  'I2C'
) AS v;

INSERT IGNORE INTO umbrales (id_aula, variable, minimo, maximo)
SELECT a.id_aula, v.variable, v.minimo, v.maximo
FROM (SELECT id_aula FROM aulas ORDER BY id_aula LIMIT 1) AS a
CROSS JOIN (
    SELECT 'temperatura' AS variable,  10    AS minimo,    30     AS maximo UNION ALL
    SELECT 'humedad',                  20,               70 UNION ALL
    SELECT 'presion',                  800,              1100 UNION ALL
    SELECT 'iluminacion',              200,              100000
) AS v;

-- ------------------------------ DDL: relacionar mediciones con aulas --
ALTER TABLE mediciones ADD COLUMN IF NOT EXISTS id_aula INT NULL AFTER id_medicion;

-- Las mediciones que ya existian pasan a la primera aula
UPDATE mediciones SET id_aula = (SELECT MIN(id_aula) FROM aulas) WHERE id_aula IS NULL;

ALTER TABLE mediciones MODIFY id_aula INT NOT NULL;

ALTER TABLE mediciones
    ADD CONSTRAINT fk_mediciones_aula FOREIGN KEY IF NOT EXISTS (id_aula)
        REFERENCES aulas (id_aula) ON UPDATE CASCADE ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS idx_mediciones_aula_fecha ON mediciones (id_aula, fecha_hora);

-- Prueba: debe mostrar las 4 tablas y la nueva columna
SHOW TABLES;
DESCRIBE mediciones;
