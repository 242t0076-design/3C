#include <WiFi.h>
#include <ESPmDNS.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <Wire.h>
#include <Adafruit_BME280.h>
#include <BH1750.h>

#include "secrets.h"

// ====== AJUSTES ======
// Cada cuánto se manda una medición.
// 15 s es solo para PROBAR. Cuando termines de probar, cámbialo a 60000UL.
const unsigned long INTERVALO_ENVIO_MS = 60000UL;

// Si un envío falla, se reintenta pronto sin esperar todo el intervalo.
const unsigned long INTERVALO_REINTENTO_MS = 10000UL;

// Tras este número de fallos seguidos se vuelve a buscar la IP del servidor.
const int FALLOS_PARA_BUSCAR_IP = 3;
// =====================

Adafruit_BME280 bme;
BH1750 luz(0x23);
Preferences memoria;

bool bmeOk = false;
bool luzOk = false;

String ipServidor = "";
int fallosSeguidos = 0;
unsigned long proximoEnvio = 0;

// Inicia el BH1750 con reintentos en modo continuo: el sensor mide solo
// todo el tiempo y readLightLevel() devuelve la última medición.
bool iniciarLuz() {
  for (int i = 0; i < 3; i++) {
    if (luz.begin(BH1750::CONTINUOUS_HIGH_RES_MODE)) {
      delay(200);  // deja terminar la primera medición
      return true;
    }
    delay(200);
  }
  return false;
}

// ---------------------------------------------------------------- Wi-Fi ----
// Explica en español por qué no conectó, a partir del código de estado.
const char* motivoWiFi(int estado) {
  switch (estado) {
    case WL_NO_SSID_AVAIL:  return "no ve la red (senal muy debil, fuera de alcance, o la red no es de 2.4 GHz)";
    case WL_CONNECT_FAILED: return "el router rechazo la conexion (contrasena incorrecta o filtro de equipos)";
    case WL_CONNECTION_LOST:return "se perdio la conexion";
    case WL_DISCONNECTED:   return "no logro entrar (senal debil o router saturado)";
    default:                return "sin respuesta del router";
  }
}

// Busca tu red y dice con qué señal la ve el ESP32.
void diagnosticarSenal() {
  Serial.println("Buscando redes para medir la senal...");
  int n = WiFi.scanNetworks();
  bool vista = false;
  for (int i = 0; i < n; i++) {
    if (WiFi.SSID(i) == WIFI_SSID) {
      Serial.printf("  Tu red SI aparece: senal %d dBm, canal %d  (mejor que -70 es buena; peor que -80 es muy debil)\n",
                    WiFi.RSSI(i), WiFi.channel(i));
      vista = true;
    }
  }
  if (!vista) Serial.println("  Tu red NO aparece en el escaneo: acerca el ESP32 al router o revisa que sea de 2.4 GHz.");
  WiFi.scanDelete();
}

void conectarWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;

  Serial.printf("Conectando a %s", WIFI_SSID);
  WiFi.disconnect(true);   // limpia el intento anterior: sin esto el ESP32 a veces se atora
  delay(200);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);    // mas estable en routers saturados
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  unsigned long inicio = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - inicio < 15000) {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("\nWiFi conectado. IP del ESP32: ");
    Serial.println(WiFi.localIP());
    Serial.printf("Senal: %d dBm\n", WiFi.RSSI());
    MDNS.begin("esp32-aula");  // necesario para poder consultar nombres .local
  } else {
    int estado = WiFi.status();
    Serial.printf("\nNo se pudo conectar al WiFi (codigo %d): %s\n", estado, motivoWiFi(estado));
    diagnosticarSenal();
  }
}

// ------------------------------------------------- Localizar al servidor ----

//   1) Preguntar por el nombre de la PC (mDNS)
//   2) Última IP que funcionó (guardada en memoria del ESP32)
//   3) IP de respaldo de secrets.h
void buscarServidor() {
  IPAddress ip = MDNS.queryHost(SERVER_HOST, 3000);
  if (ip != IPAddress(0, 0, 0, 0)) {
    ipServidor = ip.toString();
    Serial.printf("Servidor encontrado por nombre (%s): %s\n", SERVER_HOST, ipServidor.c_str());
    memoria.putString("ip", ipServidor);
    return;
  }

  String guardada = memoria.getString("ip", "");
  if (guardada.length() > 0 && guardada != ipServidor) {
    ipServidor = guardada;
    Serial.printf("Nombre no resuelto; uso la ultima IP buena: %s\n", ipServidor.c_str());
    return;
  }

  if (ipServidor.length() == 0 && strlen(SERVER_IP_RESPALDO) > 0) {
    ipServidor = SERVER_IP_RESPALDO;
    Serial.printf("Nombre no resuelto; uso la IP de respaldo: %s\n", ipServidor.c_str());
  }
}

// ----------------------------------------------------------- Mediciones ----
// Muestra el estado de los sensores y sus lecturas. No necesita Wi-Fi.
void mostrarLecturas() {
  if (!bmeOk) bmeOk = bme.begin(0x76);
  if (!luzOk) luzOk = iniciarLuz();

  Serial.printf("Sensores -> BME280: %s | BH1750: %s", bmeOk ? "OK" : "FALLA", luzOk ? "OK" : "FALLA");
  if (bmeOk && luzOk) {
    Serial.printf(" | Temp=%.1f C  Hum=%.1f %%  Presion=%.1f hPa  Luz=%.1f lx",
                  bme.readTemperature(), bme.readHumidity(), bme.readPressure() / 100.0F,
                  luz.readLightLevel());
  }
  Serial.println();
}

// Devuelve true si el servidor guardó la medición (HTTP 201).
bool enviarMedicion() {
  // Si un sensor no arrancó al encender, se intenta de nuevo aquí.
  if (!bmeOk) bmeOk = bme.begin(0x76);
  if (!luzOk) luzOk = iniciarLuz();
  if (!bmeOk || !luzOk) {
    Serial.println("Un sensor no esta disponible, no se envia.");
    return false;
  }

  float temperatura = bme.readTemperature();
  float humedad     = bme.readHumidity();
  float presion     = bme.readPressure() / 100.0F;
  float lux         = luz.readLightLevel();

  if (isnan(temperatura) || isnan(humedad) || isnan(presion) || lux < 0) {
    Serial.println("Lectura invalida, no se envia.");
    return false;
  }

  char json[160];
  snprintf(json, sizeof(json),
           "{\"temperatura\":%.2f,\"humedad\":%.2f,\"presion\":%.2f,\"iluminacion\":%.2f}",
           temperatura, humedad, presion, lux);

  if (ipServidor.length() == 0) {
    Serial.println("Aun no se conoce la IP del servidor.");
    return false;
  }

  String url = "http://" + ipServidor + ":" + String(SERVER_PORT) + "/api/medicion";

  HTTPClient http;
  http.begin(url);
  http.setTimeout(8000);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-API-Key", API_KEY);

  int codigo = http.POST(json);
  Serial.printf("Enviado: %s -> HTTP %d\n", json, codigo);
  if (codigo <= 0) {
    Serial.printf("Error de conexion: %s\n", http.errorToString(codigo).c_str());
  }
  http.end();

  return codigo == 201;
}

// ---------------------------------------------------------------- Arranque ----
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);  // SDA = D21, SCL = D22
  Wire.setClock(100000);
  delay(300);          // deja que los sensores se estabilicen al encender

  memoria.begin("monitoreo", false);

  bmeOk = bme.begin(0x76);
  luzOk = iniciarLuz();
  if (!bmeOk) Serial.println("ERROR: no se encontro el BME280 en 0x76");
  if (!luzOk) Serial.println("ERROR: no se encontro el GY-302 en 0x23");

  mostrarLecturas();  // para ver los sensores desde el arranque, aunque no haya Wi-Fi

  conectarWiFi();
  if (WiFi.status() == WL_CONNECTED) buscarServidor();

  proximoEnvio = millis();  // primer envío de inmediato
}


void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    mostrarLecturas();  // sin Wi-Fi igual se ven los sensores en el Monitor Serie
    conectarWiFi();
    if (WiFi.status() == WL_CONNECTED) buscarServidor();
    delay(1000);
    return;
  }

  if ((long)(millis() - proximoEnvio) >= 0) {
    if (enviarMedicion()) {
      fallosSeguidos = 0;
      memoria.putString("ip", ipServidor);  // esta IP funciona: se recuerda
      proximoEnvio = millis() + INTERVALO_ENVIO_MS;
    } else {
      fallosSeguidos++;
      if (fallosSeguidos >= FALLOS_PARA_BUSCAR_IP) {
        Serial.println("Varios fallos seguidos: busco de nuevo al servidor...");
        buscarServidor();
        fallosSeguidos = 0;
      }
      proximoEnvio = millis() + INTERVALO_REINTENTO_MS;
    }
  }

  delay(50);
}