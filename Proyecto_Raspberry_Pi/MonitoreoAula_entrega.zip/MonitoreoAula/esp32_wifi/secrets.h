#pragma once

// Wi-Fi de 2.4 GHz
#define WIFI_SSID ""
#define WIFI_PASS ""

// Debe ser IGUAL a API_KEY del archivo .env del servidor
#define API_KEY "52a94c03fcbfcf0a2c01880c6d9bd819"

// Nombre de la Raspberry (sin ".local")
#define SERVER_HOST "aula-pi"
#define SERVER_PORT 5000

// IP de respaldo, solo se usa si el nombre no se logra resolver
#define SERVER_IP_RESPALDO ""