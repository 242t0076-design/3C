-- Para TU BASE DE DATOS YA EXISTENTE: solo agrega la tabla de usuarios del login.
-- Ejecutar en phpMyAdmin (pestaña SQL). No borra nada.
USE `monitoreo_aula`;

CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario      INT AUTO_INCREMENT PRIMARY KEY,
    nombre_usuario  VARCHAR(50)  NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    rol             ENUM('admin','usuario') NOT NULL DEFAULT 'usuario',
    activo          TINYINT(1)   NOT NULL DEFAULT 1,
    fecha_creacion  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- El usuario de la app ya tiene SELECT e INSERT sobre toda la base,
-- que es lo único que necesita el login y crear_usuario.py.
