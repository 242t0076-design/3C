import hmac
import math
import os
import time
from datetime import datetime

from dotenv import load_dotenv
from flask import (
    Flask,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from flask_wtf.csrf import CSRFProtect
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import check_password_hash, generate_password_hash

from base_datos import (
    guardar_medicion_bd,
    obtener_mediciones_bd,
    obtener_usuario_activo,
)

load_dotenv()

# Clave que debe mandar el ESP32 en el encabezado X-API-Key.
API_KEY = os.getenv("API_KEY")

# Clave para firmar las sesiones. Es obligatoria: sin ella el login no es seguro.
SECRET_KEY = os.getenv("SECRET_KEY")
if not SECRET_KEY:
    raise RuntimeError(
        "Falta SECRET_KEY en el archivo .env (ver .env.example)."
    )

# Rangos razonables para descartar lecturas dañadas.
LIMITES = {
    "temperatura": (-40, 85),
    "humedad": (0, 100),
    "presion": (300, 1100),
    "iluminacion": (0, 100000),
}

# Límite de intentos de login por IP: 5 fallos -> bloqueo de 60 segundos.
MAX_INTENTOS = 5
BLOQUEO_SEGUNDOS = 60
_intentos_fallidos = {}  # ip -> (cantidad, momento_del_ultimo_fallo)

# Hash de relleno: se compara aunque el usuario no exista, para que la
# respuesta tarde lo mismo y no se pueda adivinar qué usuarios existen.
_HASH_RELLENO = generate_password_hash("relleno-no-valido")

app = Flask(__name__)
app.config.update(
    SECRET_KEY=SECRET_KEY,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    # Ponlo en True solo si algún día sirves el panel con HTTPS.
    SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "0") == "1",
    PERMANENT_SESSION_LIFETIME=1 * 3600,  # la sesión dura 1 hora
)

# Detrás de un túnel (Tailscale/Cloudflare) todas las visitas llegan desde
# 127.0.0.1; ProxyFix lee la IP real del encabezado X-Forwarded-For para que el
# límite de intentos de login cuente por visitante y no bloquee a todos juntos.
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

csrf = CSRFProtect(app)

# Rutas que se pueden abrir sin haber iniciado sesión.
RUTAS_PUBLICAS = {"static", "iniciar_sesion", "recibir_medicion"}


@app.after_request
def agregar_cabeceras_seguridad(respuesta):
    respuesta.headers["X-Content-Type-Options"] = "nosniff"
    respuesta.headers["X-Frame-Options"] = "DENY"
    respuesta.headers["Referrer-Policy"] = "same-origin"
    respuesta.headers["Cache-Control"] = "no-store"
    return respuesta


@app.before_request
def proteger_rutas():
    if request.endpoint in RUTAS_PUBLICAS or request.endpoint is None:
        return None

    if "id_usuario" in session:
        return None

    if request.path.startswith("/api/"):
        return jsonify({"error": "Sesión no iniciada."}), 401

    return redirect(url_for("iniciar_sesion"))


def _clave_valida(clave_recibida):
    """Compara la clave del ESP32 en tiempo constante."""
    if not API_KEY or not clave_recibida:
        return False
    return hmac.compare_digest(
        clave_recibida.encode("utf-8"), API_KEY.encode("utf-8")
    )


def _ip_bloqueada(ip):
    cantidad, ultimo = _intentos_fallidos.get(ip, (0, 0))
    if cantidad >= MAX_INTENTOS:
        if time.time() - ultimo < BLOQUEO_SEGUNDOS:
            return True
        _intentos_fallidos.pop(ip, None)
    return False


def _registrar_fallo(ip):
    cantidad, _ = _intentos_fallidos.get(ip, (0, 0))
    _intentos_fallidos[ip] = (cantidad + 1, time.time())


# ---------------------------------------------------------------- Login ----
@app.route("/login", methods=["GET", "POST"])
def iniciar_sesion():
    if request.method == "GET":
        if "id_usuario" in session:
            return redirect(url_for("inicio"))
        return render_template("login.html", error=None)

    ip = request.remote_addr or "desconocida"
    if _ip_bloqueada(ip):
        return render_template(
            "login.html",
            error="Demasiados intentos. Espera un minuto e inténtalo de nuevo.",
        ), 429

    nombre = (request.form.get("usuario") or "").strip()
    contrasena = request.form.get("contrasena") or ""

    try:
        usuario = obtener_usuario_activo(nombre)
    except Exception:
        app.logger.exception("Error al consultar el usuario")
        return render_template(
            "login.html", error="No fue posible iniciar sesión ahora."
        ), 500

    hash_guardado = usuario["password_hash"] if usuario else _HASH_RELLENO
    correcto = check_password_hash(hash_guardado, contrasena)

    if not usuario or not correcto:
        _registrar_fallo(ip)
        return render_template(
            "login.html", error="Usuario o contraseña incorrectos."
        ), 401

    _intentos_fallidos.pop(ip, None)
    session.clear()
    session.permanent = True
    session["id_usuario"] = usuario["id_usuario"]
    session["nombre_usuario"] = usuario["nombre_usuario"]
    session["rol"] = usuario["rol"]
    return redirect(url_for("inicio"))


@app.route("/logout", methods=["POST"])
def cerrar_sesion():
    session.clear()
    return redirect(url_for("iniciar_sesion"))


# ---------------------------------------------------------------- Panel ----
@app.route("/")
def inicio():
    return render_template("index.html", usuario=session.get("nombre_usuario"))


# ------------------------------------------------------------ API ESP32 ----
@csrf.exempt  # el ESP32 no puede enviar token CSRF; se protege con la API key
@app.route("/api/medicion", methods=["POST"])
def recibir_medicion():
    """Recibe una medición enviada por el ESP32 y la guarda en MySQL."""
    if not _clave_valida(request.headers.get("X-API-Key")):
        return jsonify({"error": "No autorizado."}), 401

    datos = request.get_json(silent=True)
    if not isinstance(datos, dict):
        return jsonify({"error": "Se esperaba un JSON."}), 400

    medicion = {}
    for campo, (minimo, maximo) in LIMITES.items():
        try:
            valor = float(datos[campo])
        except (KeyError, TypeError, ValueError):
            return jsonify({"error": f"Falta o es inválido: {campo}"}), 400

        if not math.isfinite(valor) or not (minimo <= valor <= maximo):
            return jsonify({"error": f"Fuera de rango: {campo}"}), 400

        medicion[campo] = round(valor, 2)

    # El ESP32 no tiene reloj: la hora la pone el servidor.
    medicion["fecha"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    medicion["simulado"] = False

    try:
        guardar_medicion_bd(medicion)
    except Exception:
        app.logger.exception("Error al guardar la medición del ESP32")
        return jsonify({"error": "No fue posible guardar la medición."}), 500

    print("Medición recibida del ESP32:", medicion)
    return jsonify({"ok": True}), 201


# ------------------------------------------------------------ API panel ----
@app.route("/api/historial")
def historial():
    """Últimas 100 mediciones; la primera es la más reciente."""
    try:
        filas = obtener_mediciones_bd(limite=100)
        return jsonify(filas), 200

    except Exception:
        app.logger.exception("Error al consultar el historial de mediciones")
        return jsonify({"error": "No fue posible consultar el historial."}), 500


# ----------------------------------------------------------- Descargas ----
def _mediciones_para_exportar():
    filas = obtener_mediciones_bd(limite=30)
    aula = filas[0]["aula"] if filas else "Aula"
    return filas, aula


@app.route("/exportar/mediciones.xlsx")
def exportar_excel():
    from exportar import generar_excel
    from flask import send_file

    try:
        filas, aula = _mediciones_para_exportar()
        archivo = generar_excel(filas, aula)
    except Exception:
        app.logger.exception("Error al generar el Excel")
        return "No fue posible generar el archivo.", 500
    return send_file(
        archivo,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="ultimas_30_mediciones.xlsx",
    )


@app.route("/exportar/mediciones.pdf")
def exportar_pdf():
    from exportar import generar_pdf
    from flask import send_file

    try:
        filas, aula = _mediciones_para_exportar()
        archivo = generar_pdf(filas, aula)
    except Exception:
        app.logger.exception("Error al generar el PDF")
        return "No fue posible generar el archivo.", 500
    return send_file(
        archivo,
        mimetype="application/pdf",
        as_attachment=True,
        download_name="ultimas_30_mediciones.pdf",
    )


if __name__ == "__main__":
    # 0.0.0.0 permite que el ESP32 (otro dispositivo de la red) llegue al servidor.
    app.run(debug=False, use_reloader=False, host="0.0.0.0", port=5000)
