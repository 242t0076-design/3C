-- =====================================================================
-- EJEMPLOS DE DML (INSERT, UPDATE, DELETE) - para la seccion de DML del reporte
-- Ejecutar con el usuario administrador:  sudo mariadb < dml_ejemplos.sql
-- =====================================================================
USE `monitoreo_aula`;

-- INSERT: agregar un aula nueva con un sensor
INSERT INTO aulas (nombre, ubicacion) VALUES ('Aula de Prueba', 'Edificio B');
INSERT INTO sensores (id_aula, modelo, magnitud, unidad, interfaz)
VALUES ((SELECT id_aula FROM aulas WHERE nombre = 'Aula de Prueba'), 'BME280', 'temperatura', 'C', 'I2C');

-- UPDATE: cambiar la ubicacion y el limite de temperatura
UPDATE aulas SET ubicacion = 'Edificio B, planta alta' WHERE nombre = 'Aula de Prueba';
UPDATE umbrales SET maximo = 28
WHERE variable = 'temperatura'
  AND id_aula = (SELECT id_aula FROM aulas ORDER BY id_aula LIMIT 1);

-- Comprobar
SELECT a.nombre, a.ubicacion, COUNT(s.id_sensor) AS sensores
FROM aulas AS a LEFT JOIN sensores AS s ON s.id_aula = a.id_aula
GROUP BY a.id_aula, a.nombre, a.ubicacion;

-- DELETE: borrar el aula de prueba (ON DELETE CASCADE borra tambien sus sensores)
DELETE FROM aulas WHERE nombre = 'Aula de Prueba';

-- Regresar el limite a su valor original
UPDATE umbrales SET maximo = 30
WHERE variable = 'temperatura'
  AND id_aula = (SELECT id_aula FROM aulas ORDER BY id_aula LIMIT 1);
