-- Script para crear la base de datos del proyecto Monitoreo del Aula.
-- Ejecutar en phpMyAdmin (pestana SQL) con el usuario root de XAMPP.
-- Es seguro ejecutarlo mas de una vez: no borra nada.

CREATE DATABASE IF NOT EXISTS `monitoreo_aula`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Usuario de la aplicacion (los mismos datos que estan en el archivo .env).
CREATE USER IF NOT EXISTS 'monitoreo_app'@'localhost' IDENTIFIED BY 'MTprvdgHBqfWA2h93vtuzZ3b';
-- (Esta clave ya coincide con DB_PASSWORD de tu .env.
--  Ya no hay ALTER USER: así, volver a ejecutar el script no te cambia la contraseña.)

-- Permisos minimos: solo guardar (INSERT) y consultar (SELECT).
GRANT SELECT, INSERT ON `monitoreo_aula`.* TO 'monitoreo_app'@'localhost';
FLUSH PRIVILEGES;

USE `monitoreo_aula`;

CREATE TABLE IF NOT EXISTS mediciones (
    id_medicion  INT AUTO_INCREMENT PRIMARY KEY,
    fecha_hora   DATETIME      NOT NULL,
    temperatura  DECIMAL(5,2)  NOT NULL,
    humedad      DECIMAL(5,2)  NOT NULL,
    presion      DECIMAL(7,2)  NOT NULL,
    iluminacion  DECIMAL(9,2)  NOT NULL,
    es_simulada  BOOLEAN       NOT NULL DEFAULT FALSE,
    INDEX idx_mediciones_fecha (fecha_hora)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario      INT AUTO_INCREMENT PRIMARY KEY,
    nombre_usuario  VARCHAR(50)  NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    rol             ENUM('admin','usuario') NOT NULL DEFAULT 'usuario',
    activo          TINYINT(1)   NOT NULL DEFAULT 1,
    fecha_creacion  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Prueba: debe mostrar la estructura de la tabla.
DESCRIBE mediciones;
